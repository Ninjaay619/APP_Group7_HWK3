package com.example.group7_hwk3_to_dolist

import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import androidx.activity.viewModels
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.todolist.TaskAdapter
import com.example.todolist.TaskViewModel

class MainActivity : AppCompatActivity() {

    private val taskViewModel: TaskViewModel by viewModels()
    private lateinit var taskAdapter: TaskAdapter

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val recyclerView = findViewById<RecyclerView>(R.id.recyclerView)
        val inputTask = findViewById<EditText>(R.id.editTextTask)
        val addButton = findViewById<Button>(R.id.buttonAdd)

        taskAdapter = TaskAdapter { task ->
            taskViewModel.removeTask(task)
        }

        recyclerView.layoutManager = LinearLayoutManager(this)
        recyclerView.adapter = taskAdapter

        taskViewModel.taskList.observe(this) { tasks ->
            taskAdapter.submitList(tasks)
        }

        addButton.setOnClickListener {
            val taskText = inputTask.text.toString()
            if (taskText.isNotBlank()) {
                taskViewModel.addTask(taskText)
                inputTask.text.clear()
            }
        }
    }
}

