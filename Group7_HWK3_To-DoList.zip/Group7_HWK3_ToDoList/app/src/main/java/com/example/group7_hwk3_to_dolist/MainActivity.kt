package com.example.group7_hwk3_to_dolist
import android.os.Bundle
import android.text.InputType
import android.widget.Button
import android.widget.EditText
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.activity.viewModels
import androidx.recyclerview.widget.ItemTouchHelper
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.todolist.TaskAdapter
import com.example.todolist.TaskViewModel

class MainActivity : AppCompatActivity() {

    private val taskViewModel: TaskViewModel by viewModels()
    private lateinit var taskAdapter: TaskAdapter

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val recyclerView = findViewById<RecyclerView>(R.id.recyclerView)
        val inputEditText = findViewById<EditText>(R.id.inputEditText)
        val addButton = findViewById<Button>(R.id.addButton)

        taskAdapter = TaskAdapter(
            mutableListOf(),
            onDeleteTask = { taskViewModel.removeTask(it) },
            onMoveTask = { from, to -> taskViewModel.moveTask(from, to) },
            onUpdateTask = { index, newTask -> taskViewModel.updateTask(index, newTask) }
        )

        recyclerView.adapter = taskAdapter
        recyclerView.layoutManager = LinearLayoutManager(this)

        taskViewModel.tasks.observe(this) { tasks ->
            taskAdapter.updateData(tasks.toList())
        }

        addButton.setOnClickListener {
            val text = inputEditText.text.toString()
            if (text.isNotBlank()) {
                taskViewModel.addTask(text)
                inputEditText.text.clear()
            }
        }
    }
}


