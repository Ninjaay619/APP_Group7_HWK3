package com.example.todolist

import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel

class TaskViewModel : ViewModel() {
    private val _taskList = MutableLiveData<List<String>>(emptyList())
    val taskList: LiveData<List<String>> = _taskList

    fun addTask(task: String) {
        _taskList.value = _taskList.value!! + task
    }

    fun removeTask(task: String) {
        _taskList.value = _taskList.value!!.filterNot { it == task }
    }
}
