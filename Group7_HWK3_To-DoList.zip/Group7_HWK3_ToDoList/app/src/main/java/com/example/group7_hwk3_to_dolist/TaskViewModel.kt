package com.example.todolist
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel

class TaskViewModel : ViewModel() {
    private val _tasks = MutableLiveData<MutableList<String>>(mutableListOf())
    val tasks: LiveData<MutableList<String>> = _tasks

    fun addTask(task: String) {
        _tasks.value?.add(task)
        _tasks.postValue(_tasks.value)
    }

    fun removeTask(task: String) {
        _tasks.value?.remove(task)
        _tasks.postValue(_tasks.value)
    }

    fun moveTask(fromIndex: Int, toIndex: Int) {
        _tasks.value?.let {
            val task = it.removeAt(fromIndex)
            it.add(toIndex, task)
            _tasks.postValue(it)
        }
    }

    fun updateTask(index: Int, newTask: String) {
        _tasks.value?.let {
            it[index] = newTask
            _tasks.postValue(it)
        }
    }
}
