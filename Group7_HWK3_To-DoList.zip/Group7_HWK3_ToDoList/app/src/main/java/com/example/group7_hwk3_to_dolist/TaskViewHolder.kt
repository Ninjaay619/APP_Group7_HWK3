package com.example.todolist

import android.view.View
import android.widget.CheckBox
import android.widget.ImageButton
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.example.group7_hwk3_to_dolist.R

class TaskViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
    val taskText: TextView = itemView.findViewById(R.id.taskText)
    val checkBoxDone: CheckBox = itemView.findViewById(R.id.checkBoxDone)
    val btnDelete: ImageButton = itemView.findViewById(R.id.btnDelete)
    val btnUp: ImageButton = itemView.findViewById(R.id.btnUp)
    val btnDown: ImageButton = itemView.findViewById(R.id.btnDown)
    val btnEdit: ImageButton = itemView.findViewById(R.id.btnEdit)
}
