package com.example.todolist

import android.app.AlertDialog
import android.view.LayoutInflater
import android.view.ViewGroup
import android.widget.EditText
import androidx.recyclerview.widget.RecyclerView
import com.example.group7_hwk3_to_dolist.R

class TaskAdapter(
    private val taskList: MutableList<String>,
    private val onDeleteTask: (String) -> Unit,
    private val onMoveTask: (Int, Int) -> Unit,
    private val onUpdateTask: (Int, String) -> Unit
) : RecyclerView.Adapter<TaskViewHolder>() {

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): TaskViewHolder {
        val view = LayoutInflater.from(parent.context)
            .inflate(R.layout.item_task, parent, false)
        return TaskViewHolder(view)
    }
    fun updateData(newList: List<String>) {
        taskList.clear()
        taskList.addAll(newList)
        notifyDataSetChanged()
    }
    override fun getItemCount(): Int = taskList.size

    override fun onBindViewHolder(holder: TaskViewHolder, position: Int) {
        val task = taskList[position]
        holder.taskText.text = task

        holder.checkBoxDone.isChecked = false  // 預設為未勾選

        holder.checkBoxDone.setOnCheckedChangeListener { _, isChecked ->
            if (isChecked) {
                onDeleteTask(task)  // 勾選後自動刪除
            }
        }

        holder.btnDelete.setOnClickListener {
            onDeleteTask(task)
        }

        holder.btnUp.setOnClickListener {
            if (position > 0) onMoveTask(position, position - 1)
        }

        holder.btnDown.setOnClickListener {
            if (position < taskList.size - 1) onMoveTask(position, position + 1)
        }

        holder.btnEdit.setOnClickListener {
            val editText = EditText(holder.itemView.context).apply {
                setText(task)
            }

            AlertDialog.Builder(holder.itemView.context)
                .setTitle("Edit Task")
                .setView(editText)
                .setPositiveButton("Save") { _, _ ->
                    val updatedText = editText.text.toString()
                    if (updatedText.isNotBlank()) {
                        onUpdateTask(position, updatedText)
                    }
                }
                .setNegativeButton("Cancel", null)
                .show()
            }
        }
    }